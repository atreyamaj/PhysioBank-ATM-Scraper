f = open('Download_log.txt', 'a')
f.write('hello\n')
f.write('bye\n')
f.close()